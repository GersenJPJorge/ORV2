import { Observable} from 'rxjs/Observable';
import { Empresas } from './../../models/models-empresas';
import { EmpresasService } from './../../services/empresas-service';
import { Component, OnInit } from '@angular/core';
import { Injectable } from '@angular/core';
import 'rxjs/add/observable/throw';
// import 'rxjs-operators';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/mergeMap';

@Component({
  selector: 'app-empresas-cadastrar',
  templateUrl: './empresas-cadastrar.component.html',
  styleUrls: ['./empresas-cadastrar.component.css']
})
export class EmpresasCadastrarComponent implements OnInit {
  empresasService: any;
  router: any;

	private empresa: Empresas;
	private msgErro: string;

  constructor

  (private empresaService: EmpresasService) {
  }

ngOnInit() {
    this.empresa = new Empresas();
  }

  cadastrar(): Observable <any> {
      return this.empresasService.cadastrar(this.empresa)
             .map(this.router.navigate(['/empresa-listar']))
             .catch(this.msgErro);
	}
}
