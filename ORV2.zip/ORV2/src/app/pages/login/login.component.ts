import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';

import { Md5 } from 'ts-md5/dist/md5';

@Component({
  selector: 'app-login',
  templateUrl: 'login.component.html',
  styleUrls: ['login.component.css']
})


export class LoginComponent implements OnInit {

  userLogin: any;
  userPass: any;
  userDocument: any;
  smsCode: any;
  token: any;

  constructor(private http: HttpClient, private router: Router) { }

  ngOnInit() {
    /*
    this.http.get('https://api.github.com/users/seeschweiler').subscribe(data => {
      console.log(data);
      console.log(data['subscriptions_url']);
      console.log(data['subscriptions_url']);
    }); */
  }

  login(userLogin: any, userPass: any, token: any, userDocument: any, smsCode: any) {
    // Aqui vai qualquer função para validar na API se o login existe...

    if (this.userLogin && this.userPass) {
      document.getElementById('msg-erro-login').style.display = 'none';

      const urlGetToken = 'https://api.orbitallcartoes.com.br/token';
      const password = Md5.hashStr(this.userPass);
      const bodyGetToken: string = 'grant_type=password&username=' + this.userLogin + '&password=' + password;

      this.http.post(urlGetToken, bodyGetToken, {
          headers: new HttpHeaders()
              .set('Content-Type',    'application/x-www-form-urlencoded')
              .set('Authorization',   'Basic cmV0YWd1YXJkYTpvcmJpdGFsbA==')
              .set('systemName',      'siteOle')
              .set('environmentName', 'hml')
              .set('productName',     'appOrbitallCard')
      })
      .subscribe(
        data => {
          // this.token = data['access_token'];
          this.token = data['tokenBackEnd']['OAuth2AccessToken']['access_token'];
          console.log(data);

          // const bodyObterVersao: string = 'documentNumber=' + this.userDocument + '&smsCode=' + this.smsCode;
          /*
          const urlObterVersao = 'https://api.orbitallcartoes.com.br/esb-orbitall/termo/obterVersao';

          this.http.get(urlObterVersao, {
              headers: new HttpHeaders()
                  .set('Content-Type',    'application/x-www-form-urlencoded')
                  .set('Authorization',   'Bearer ' + this.token + '')
                  .set('systemName',      'siteOle')
                  .set('environmentName', 'hml')
                  .set('productName',     'appOrbitallCard')
          })
          .subscribe(data2 => {
              console.log('eeee: ' + JSON.stringify(data2));
            },
            error => {
              console.log('xwed23d');
            }
          );
          */
          this.router.navigate(['/']);
        },
        error => {
          document.getElementById('msg-erro-login').style.display = 'block';
        }
      );
    } else {
      document.getElementById('msg-erro-login').style.display = 'block';
    }
  }
}
