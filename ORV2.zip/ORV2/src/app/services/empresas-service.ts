import { Empresas } from './../models/models-empresas';
import {Injectable} from '@angular/core';

@Injectable()
export class EmpresasService {

	private empresas: Empresas[] = [
    new Empresas
    ( 1, 1, 'Empresa1', 12345678901, '01012017', '01010001'),
	];

	listarTodos() {
		return this.empresas;
	}

	cadastrar(empresas: Empresas) {
		this.empresas.push(empresas);
	}

	atualizar(id: number, empresas: Empresas) {
		this.empresas[id] = empresas;
	}

	excluir(id: number) {
		this.empresas.splice(id, 1);
	}
}
