import { EmpresasListarComponent} from './empresas/empresas-listar/empresas-listar.component'
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { EmpresasComponent } from './pages/empresas/empresas.component';
import { ConfiguracoesComponent } from './pages/configuracoes/configuracoes.component';
import { UsuariosComponent } from './pages/usuarios/usuarios.component';

const routes: Routes = [
    // home
    {
        path: '',
        redirectTo: 'Login',
        pathMatch: 'full'
    },

    // login
    {
        path: 'login',
        component: LoginComponent,
        data: {title: 'Login'}
    },
    // logout
    {
        path: 'logout',
        component: LoginComponent,
        data: {title: 'Logout'}
    },
    // empresas
    {
        path: 'empresas',
        component: EmpresasListarComponent,
        data: {title: 'Empresas'}
    },
    // configuracoes
    {
        path: 'configuracoes',
        component: ConfiguracoesComponent,
        data: {title: 'Configurações'}
    },
    // usuarios
    {
        path: 'usuarios',
        component: UsuariosComponent,
        data: {title: 'Usuários'}
    }
];

export const RoutingModule = RouterModule.forRoot(routes);
