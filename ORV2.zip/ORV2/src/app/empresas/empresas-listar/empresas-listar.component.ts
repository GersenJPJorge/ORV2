import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empresas-listar',
  templateUrl: './empresas-listar.component.html',
  styleUrls: ['./empresas-listar.component.css']
})
export class EmpresasListarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}


