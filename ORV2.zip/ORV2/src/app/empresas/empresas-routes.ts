import { EmpresasListarComponent } from './empresas-listar/empresas-listar.component';
import { EmpresasCadastrarComponent} from './empresas-cadastrar/empresas-cadastrar.component'

import { Routes, RouterModule } from '@angular/router'
const routes: Routes = [
    // home
    {
        path: '',
        component: EmpresasListarComponent
    },

    {
        path: 'empresas-listar',
        component: EmpresasListarComponent
    },
    {
      path: 'empresas-cadastrar',
      component: EmpresasCadastrarComponent
  },]
export const RoutingModule = RouterModule.forRoot(routes);
